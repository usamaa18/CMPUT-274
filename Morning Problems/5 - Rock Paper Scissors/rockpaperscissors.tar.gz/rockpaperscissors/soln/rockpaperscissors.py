num_matches = int(input())

for i in range(num_matches):
    pass
    # now you do the rest!
    # read in the rounds in this match
    # example: if the line of input was "RR RP SR" then
    # rounds == ["RR", "RP", "SR"]
    

# print here whoever is the overall winner of all the matches and
# how many matches the winner won
