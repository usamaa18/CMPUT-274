#!/bin/bash
g++ vote.cpp -o output -Wall && ./output
rm -f ./output
