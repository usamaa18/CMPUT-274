# Read the input
a, b, c = map(int, input().split())


# Solve the problem


# Output the result
