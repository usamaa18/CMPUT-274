#!/bin/bash
g++ manhattan.cpp -o output -Wall && ./output
rm -f ./output
