#!/bin/bash
g++ primality.cpp -o output -Wall && ./output
rm -f ./output
