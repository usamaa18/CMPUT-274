# read the input

# solve the problem

# output the result
