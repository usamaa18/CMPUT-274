#include <iostream>

using namespace std;

int main() {
  // Declare your variables

  // Read the input

  // Solve the problem
  // Last one! Good luck :)

  return 0;
}
