#!/bin/bash
g++ addition.cpp -o output -Wall && ./output
rm -f ./output
