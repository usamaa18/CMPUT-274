# Get the input
leftlane = input().split()
# now do something similar to get the list of vehicles in the right lane


# Solve the problem


# Print the result
